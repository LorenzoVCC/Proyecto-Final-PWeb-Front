import { Injectable } from '@angular/core';
import { RestaurantForCreateDTO, RestaurantForReadDTO, RestaurantForUpdateDTO, RestaurantLoginDTO, RestaurantOwnerDTO } from '../interfaces/restaurant-interface';

@Injectable({ providedIn: 'root' })

export class RestaurantService {

  restaurants: RestaurantForReadDTO[] = [
    {  
      id: 1,
      name: 'Restaurante 1',
      description: 'Descripción localhostDescripciónDescripción localhostDescripción localhostDescripción localhostDescripción localhostDescripción localhostDescripción localhostDescripción localhostDescripción localhostDescripción localhostDescripción localhost4200/',
      imageUrl: '/maldonal.jpg',
      address: 'Moreno 37',
      slug: 'res1-moreno',
      bgImage: '/comidas-fondo.jpg'
    },
    {
      id: 2,
      name: 'Restaurante 2',
      description: 'Otro restauranteDescripción localhostDescripción localhostDescripción localhostDescripción localhostDescripción localhostDescripción localhostDescripción localhost',
      address: 'Av Siempre Viva 742',
      imageUrl: '/restaurant-generic-img.jpg',
      slug: 'restaurante-2',
    },
  ];

    private credentials: { restaurantId: number; email: string; password: string }[] = [
    { restaurantId: 1, email: 'resto1@mail.com', password: '1234' },
    { restaurantId: 2, email: 'resto2@mail.com', password: '1234' },
  ];


  //Metodos GetBy
  getAll(): RestaurantForReadDTO[] {
    return this.restaurants;
  }

  getById(id:number): RestaurantForReadDTO | null {
    return this.restaurants.find(r => r.id === id) ?? null
  }

  getOwnerById(id:number): RestaurantOwnerDTO | null {
    const resto = this.getById(id);
    if (!resto) return null;

    const creds = this.credentials.find(c => c.restaurantId === id)

    return {
      id: resto.id,
      name: resto.name,
      email: creds?.email ?? '',
      description: resto.description,
      imageUrl: resto.imageUrl,
      bgImage: resto.bgImage,
      address: resto.address,
      slug: resto.slug,
      createdAt: new Date().toISOString(),
      isActive: true,                      
    }
  }

  //Fin Metodos GetBy

  register(dto:RestaurantForCreateDTO): RestaurantForReadDTO {
    const newId = Math.max(...this.restaurants.map(r => r.id), 0) + 1;

    const created: RestaurantForReadDTO = {
      id: newId,
      name: dto.name,
      description: dto.description ?? '',
      imageUrl: dto.imageUrl ?? '/restaurant-generic-img.jpg',
      bgImage: dto.bgImage ?? '/comidas-fondo',
      address: dto.address,
      slug: dto.slug,
    };

    this.restaurants.push(created);
    this.credentials.push({
      restaurantId: newId,
      email: dto.email,
      password: dto.password,
    }) 
    return created;
  }

  updateResto(id: number, dto: RestaurantForUpdateDTO): RestaurantForReadDTO | null {
    const idResto = this.restaurants.findIndex(r => r.id === id);
    if (idResto === -1) return null;

    const updated: RestaurantForReadDTO = {
      ...this.restaurants[idResto],
      ...dto,                 // pisa solo lo que venga en dto
      id: this.restaurants[idResto].id, // asegura que no se pierda el id
    };

    this.restaurants[idResto] = updated;
    return updated;
  }

  authenticate(login: RestaurantLoginDTO): number | null {
    const resfound = this.credentials.find(c => c.email === login.email && c.password === login.password);
    return resfound ? resfound.restaurantId: null;
  }

}

