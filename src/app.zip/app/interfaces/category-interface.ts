export interface CategoryForReadDTO {
  Id_Category: number;     
  Name: string;
  Id_Restaurant: number;
}

export interface CategoryCreateUpdateDTO {
  Name: string;
}
